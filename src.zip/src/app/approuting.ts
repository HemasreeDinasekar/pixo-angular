import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainnavComponent } from './mainnav/mainnav.component';
import { NavbarComponent } from './navbar/navbar.component';
import { LoginComponent } from './login/login.component';
import { UploadComponent } from './upload/upload.component';
import { SignupComponent } from './signup/signup.component';
import { MultiComponent } from './multi/multi.component';
import { FollowComponent } from './follow/follow.component';
import { MediaComponent } from './media/media.component';
import { AccountComponent } from './account/account.component';

const routes: Routes = [
  {path:'',pathMatch:'full', redirectTo:'navbar'},
  { path: 'mainnav', component: MainnavComponent },
  { path: 'navbar', component: NavbarComponent },
  { path: 'login', component: LoginComponent},
  { path: 'upload', component: UploadComponent},
  { path: 'signup', component: SignupComponent},
  { path: 'multi', component: MultiComponent},
  { path: 'follow', component: FollowComponent},
  { path: 'media', component: MediaComponent},
  { path: 'account', component: AccountComponent},
    ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
