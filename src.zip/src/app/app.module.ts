import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './approuting';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { MainnavComponent } from './mainnav/mainnav.component';
import { LoginComponent } from './login/login.component';
import { UploadComponent } from './upload/upload.component';
import { SignupComponent } from './signup/signup.component';
import { MultiComponent } from './multi/multi.component';
import { FollowComponent } from './follow/follow.component';
import { MediaComponent } from './media/media.component';
import { AccountComponent } from './account/account.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    MainnavComponent,
    LoginComponent,
    UploadComponent,
    SignupComponent,
    MultiComponent,
    FollowComponent,
    MediaComponent,
    AccountComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
