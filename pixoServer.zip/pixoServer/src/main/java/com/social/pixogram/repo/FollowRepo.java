package com.social.pixogram.repo;

import org.springframework.data.repository.CrudRepository;

import com.social.pixogram.model.Follow;

public interface FollowRepo extends CrudRepository<Follow, Long>{

}
