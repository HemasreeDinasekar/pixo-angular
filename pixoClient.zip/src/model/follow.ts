export class Follow {
    id: number;
    userId: number;
    followId: number;
}